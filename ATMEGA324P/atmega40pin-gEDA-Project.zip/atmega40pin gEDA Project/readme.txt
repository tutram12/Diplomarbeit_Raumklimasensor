ATmega DIP40 Minimal Board.

This project is a minimal development board for ATmega microcontrollers in DIP40 package.
Can be used with ATmega16, ATmega32, ATmega644, ATmega1284, ATmega1284P.

The entire project was done with gEDA. http://www.geda-project.org/

This project by Silvius is licensed under a Creative Commons Attribution 3.0 Licence
http://creativecommons.org/licenses/by/3.0/
Based on a work at http://www.openhardware.com